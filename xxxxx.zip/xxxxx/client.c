#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <unistd.h>
#include <main.h>
#include <time.h>
#include <stddef.h>
#include <xx.h>
#include <math.h>
#include <errno.h>

    //字符数组转换成16进制数据的数组
    void print_hex(const uint8_t* array, size_t length,uint8_t*output) {
        for (size_t i = 0; i < length; i += 2) {
            uint8_t byte = 0;
            byte |= (array[i] <= '9' ? array[i] - '0' : (array[i] | 0x20) - 'a' + 10) << 4;
            byte |= (array[i + 1] <= '9' ? array[i + 1] - '0' : (array[i + 1] | 0x20) - 'a' + 10);
            output[i / 2] = byte;
        }
    printf("\n");
    }

    //字符串转换成16进制数据
    size_t string_to_hex(const char* input, char * output) {
    int i;
        for (i = 0; input[i] != '\0'; i++) {
            sprintf(output + (i * 2), "%02x", input[i]);
            
        }
    //printf("%s\n",output);
    return strlen(output);
    }  
    //获取系统当前时间
    int gettime(uint8_t *Time,int len){
    // 设置时区为 GMT-8（北京时间）
    setenv("TZ", "GMT-8", 1);
    tzset();

    // 获取当前时间
    time_t currentTime;
    time(&currentTime);

    // 转换为本地时间
    struct tm *localTime = localtime(&currentTime);

    // 将北京时间的年月日时分秒赋给loginTime数组
           Time[0] = (localTime->tm_year + 1900)%100;
           Time[1] = localTime->tm_mon + 1;
           Time[2] = localTime->tm_mday;
           Time[3] = localTime->tm_hour;
           Time[4] = localTime->tm_min; 
           Time[5] = localTime->tm_sec;

    return 0;
    }
    //初始化接口
    ICV_CODE_R icv_sdk_init(int *handle, ICV_INIT_P *initp, ICV_INIT_C *initc)
    {
        if(initp == NULL || initc == NULL)
        {
            printf("error");
            return -1;
        }
        // 创建套接字
        int sockfd = socket(AF_INET, SOCK_STREAM, 0);
        if (sockfd == -1)
        {
            perror("Failed to create socket");
            return -1;
        }//设置服务端地址
        struct sockaddr_in server_addr;
        memset(&server_addr, 0, sizeof(server_addr));
        server_addr.sin_family = AF_INET;
        server_addr.sin_port = htons(initp->port);
        if (inet_pton(AF_INET, initp->ip, &(server_addr.sin_addr)) <= 0)
        {
            perror("Failed to set server address");
            return -2;
        }
        // 连接到服务端
        if (connect(sockfd, (struct sockaddr*)&server_addr, sizeof(server_addr)) == -1)
        {
            perror("Failed to connect to server");
            return -2;
        }
        else
        {
            printf("connect success\n");    
        }
        *handle=sockfd;
        return ICV_EC_OK;
    }
    //车辆登入接口
    ICV_CODE_R icv_sdk_carlogin(int handle,  ICV_DATA_HEADE *dataHeade, ICV_LOGIN_P *loginp)
    {
        if(dataHeade==NULL||loginp==NULL)
        {
            return ICV_EC_ERROR;
        }
        char buffer[4096]="232301fe";
        memset(buffer+8,0,sizeof(buffer)-8);
        int blen=strlen(buffer);
        size_t ret = string_to_hex(dataHeade->vin,buffer+blen);
        blen+=ret;
        ret = string_to_hex(dataHeade->timeStamp,buffer+blen);
        blen+=ret;
        ret = string_to_hex(dataHeade->msgId,buffer+blen);
        blen+=18;
        sprintf(buffer+blen, "%02x", dataHeade->encryptType);
        blen+=2;
        sprintf(buffer+blen, "%02x", dataHeade->maxDataNum);
        blen+=2;
        string_to_hex(dataHeade->SIM,buffer+blen);
        blen+=40;
        sprintf(buffer+blen,"%02x%02x",0x00,0x1c);
        blen+=4;
        uint8_t loginTime[MAX_TIME_LEN];
        gettime(loginTime,MAX_TIME_LEN);
        memcpy(loginp->loginTime,loginTime,sizeof(loginTime));
        for(int i=0;i<6;i++)
        {
            printf("%d",loginp->loginTime[i]);
            sprintf(buffer+blen,"%02x",loginp->loginTime[i]);
            blen+=2;
        }
        printf("\n");
        printf("%d\n",blen);
        sprintf(buffer+blen, "%04x", loginp->loginSerialNumber);
        blen+=4;
        printf("blen:%d\n",blen);
        string_to_hex(loginp->ICCID,buffer+blen);
        printf("buffer: %s\n",buffer);
        size_t length = strlen(buffer);
        uint8_t byteArray[length/2];
        printf("%ld\n",length);
        printf("接下来转换数组");
        print_hex((const uint8_t*)buffer, length,byteArray); 
        for(int i = 0; i < length/2; i++)
        {
            printf("%02x ",byteArray[i]);
        }
        printf("\n");
        //发送数据到服务端
        ssize_t bytes_sent = send(handle, byteArray, length/2, 0);
        if (bytes_sent == -1)
        {
            perror("Failed to send data");
            close(handle);
            return ICV_EC_ERROR;
            loginp->loginSerialNumber++;
        }
        else
        {
            printf("send carlogin successful\n");
            loginp->loginSerialNumber++;
        }
        uint8_t recv_data[4096];
        memset(recv_data,0,sizeof(recv_data));
        ssize_t byte_recv = recv(handle,recv_data,sizeof(recv_data),0);
        uint8_t *recvbuf = (uint8_t *)malloc(byte_recv);
        if(byte_recv > 0)
        {
            memcpy(recvbuf, recv_data, byte_recv);
            printf("recv carlogin successful\n");
            for(int i=0;i<byte_recv;i++)
            {
                printf("%02x ",recvbuf[i]);
            }
            if(recvbuf[3] ==01&&recvbuf[2]==01)
            {
                printf("收到应答正确\n");
            }
            else
            {
            printf("收到应答数据错误\n");
            }
        }
        else if(byte_recv < 0)
        {
            perror("recv failed");
            icv_sdk_close(handle);
            return ICV_EC_ERROR;
        }
        free(recvbuf);
        return ICV_EC_OK;
    }
    //车辆登出接口实现
    ICV_CODE_R icv_sdk_carlogout(int handle, ICV_DATA_HEADE *dataHeade, ICV_LOGOUT_P *logoutp)
    {
        if(dataHeade == 0 || logoutp == 0)
        {
            return ICV_EC_ERROR;
        } 
        char buf[4096]="232302fe";
        memset(buf+8,0,sizeof(buf)-8);
        int blen=strlen(buf);
        size_t ret = string_to_hex(dataHeade->vin,buf+blen);
        blen+=34;
        string_to_hex(dataHeade->timeStamp,buf+blen);
        blen+=26;
        string_to_hex(dataHeade->msgId,buf+blen);
        blen+=18;
        sprintf(buf+blen, "%02x", dataHeade->encryptType);
        blen+=2;
        sprintf(buf+blen, "%02x", dataHeade->maxDataNum);
        blen+=2;
        string_to_hex(dataHeade->SIM,buf+blen);
        blen+=40;
        sprintf(buf+blen,"%02x%02x",0x00,0x08);
        blen+=4;
        uint8_t logoutTime[MAX_TIME_LEN];
        gettime(logoutTime,MAX_TIME_LEN);  
        memcpy(logoutp->logoutTime,logoutTime,sizeof(logoutTime));
        for(int i=0;i<MAX_TIME_LEN;i++)
        {
            printf("%d",logoutp->logoutTime[i]);
            sprintf(buf+blen,"%02x",logoutp->logoutTime[i]);
            blen+=2;
        }
        printf("\n");
        sprintf(buf+blen, "%04x", logoutp->loginoutNumber);
        blen+=4;
        printf("%s\n",buf);
        size_t length = strlen(buf);
        uint8_t Array[length/2];
        printf("%ld\n",length);
        printf("接下来转换数组");
        print_hex((const uint8_t*)buf, length,Array); 
        for(int i = 0; i < length/2; i++)
        {
            printf("%02x ",Array[i]);
        }
        printf("\n");
        ssize_t sent = send(handle, Array, length/2, 0);
        if (sent == -1)
        {
            perror("Failed to send data");
            logoutp->loginoutNumber++;
            close(handle);
            return ICV_EC_ERROR;
        }
        printf("send logoutdata successful\n");  
        logoutp->loginoutNumber++;
        uint8_t recv_data[4096];
        ssize_t byte_recv = recv(handle,recv_data,sizeof(recv_data),0);
        uint8_t *recvbuf = (uint8_t *)malloc(byte_recv);
        if(byte_recv > 0)
        {
            memcpy(recvbuf, recv_data, byte_recv);
            printf("recv logoutdata successful\n");
            for(int i=0;i<byte_recv;i++)
            {
                printf("%02x ",recvbuf[i]);
            }
            if(recvbuf[3] ==01&&recvbuf[2]==02)
            {
                printf("收到应答正确\n");
            }
            else
            {
            printf("收到应答数据错误\n");
            }
        }
        else if(byte_recv < 0)
        {
            perror("recv failed");
            icv_sdk_close(handle);
            return ICV_EC_ERROR;
        }
        free(recvbuf);
        return ICV_EC_OK;
    }
    //周期性数据接口实现
    ICV_CODE_R icv_sdk_cycledata(int handle, ICV_DATA_HEADE *dataHeade, ICV_CYCLE_P *cyclep)
    {
        if(dataHeade ==0||cyclep==0)
        {
            return ICV_EC_ERROR;
        }
        char BUFFER[4096]="232303fe";
        memset(BUFFER+8,0,sizeof(BUFFER)-8);
        int blen=strlen(BUFFER);
        size_t ret = string_to_hex(dataHeade->vin,BUFFER+blen);
        blen+=34;
        ret = string_to_hex(dataHeade->timeStamp,BUFFER+blen);
        blen+=26;
        ret = string_to_hex(dataHeade->msgId,BUFFER+blen);
        blen+=18;
        sprintf(BUFFER+blen, "%02x", dataHeade->encryptType);
        blen+=2;
        sprintf(BUFFER+blen, "%02x", dataHeade->maxDataNum);
        blen+=2;
        string_to_hex(dataHeade->SIM,BUFFER+blen);
        blen+=40;
        int data_size=0;
        int len=cyclep->targetsObjectFrequency;
        printf("目标物采集频率:%d\n",len);
        if(cyclep->targetsObjectFrequency != 0)
        {
        data_size+=(len*16)+4;
        }
        int num =  cyclep->positionFrequency;
        printf("位置信息采集频率:%d\n",num);
        if(cyclep->positionFrequency != 0)
        {
        data_size+=(num*9)+4;
        }
        int len_decisionFrequency = cyclep->decisionFrequency;
        printf("决策信息体采集频率:%d\n",len_decisionFrequency);
        if(cyclep->decisionFrequency != 0)
        {
        data_size +=(len_decisionFrequency*21)+4;
        }
        printf("data_size:%d\n",data_size);
        int len_vehiclePerformanceFrequency = cyclep->vehiclePerformanceFrequency;
        printf("整车状态信息体采集频率高频:%d\n",len_vehiclePerformanceFrequency);
        if(cyclep->vehiclePerformanceFrequency != 0)
        {
        data_size +=(len_vehiclePerformanceFrequency*16)+4;
        }
        int len_sendingDataExternallyFrequency = cyclep->sendingDataExternallyFrequency;
        printf("交通信息体采集频率:%d\n",len_sendingDataExternallyFrequency);
        if(cyclep->sendingDataExternallyFrequency != 0)
        {
        data_size +=(len_sendingDataExternallyFrequency*21)+4;    
        }
        int len_roadInfoFrequency = cyclep->roadInfoFrequency;
        printf("道路信息体采集频率:%d\n",len_roadInfoFrequency);
        if(cyclep->roadInfoFrequency != 0)
        {
        data_size +=(len_roadInfoFrequency*10)+4;
        } 
        int len_environmentFrequency = cyclep->environmentFrequency;
        printf("自然环境信息体采集频率:%d\n",len_environmentFrequency);
        if(cyclep->environmentFrequency != 0)
        {
        data_size +=(len_environmentFrequency*4)+4;
        }
        int len_vehicleStatusFrequency = cyclep->vehicleStatusFrequency;
        printf("整车状态信息体数点密度采集频率:%d\n",len_vehicleStatusFrequency);
        if(cyclep->vehicleStatusFrequency != 0)
        {
        data_size +=(len_vehicleStatusFrequency*40)+4;
        }
        int len_personnelFrequency = cyclep->personnelFrequency;
        printf("用户信息体数点密度采集频率:%d\n",len_personnelFrequency);
        if(cyclep->personnelFrequency != 0)
        {
        data_size +=(len_personnelFrequency*4)+4;
        }
        int len_vehicleComponentFrequency = cyclep->vehicleComponentFrequency;
        printf("系统及部件运行状态信息体数点密度采集频率:%d\n",len_vehicleComponentFrequency);
        if(cyclep->vehicleComponentFrequency != 0)
        {
        data_size +=(len_vehicleComponentFrequency*11)+4;
        }  
        sprintf(BUFFER+blen,"%04x",data_size);//周期性数据大小
        blen+=4;
        printf("data_size:%d\n",data_size);
        if(cyclep->targetsObjectFrequency != 0)
        {
            sprintf(BUFFER+blen, "%02x", 0x01);//类型标识
            blen+=2;
            sprintf(BUFFER+blen, "%02x",cyclep->targetsObjectFrequency);//采集频率
            blen+=2;
            sprintf(BUFFER+blen,"%04x",len*16);//目标物数据大小
            blen+=4;
        }
        for(int i=0;i<len;i++)
        {
            sprintf(BUFFER+blen, "%02x", cyclep->targetsObject[i].type);
            blen+=2;
            sprintf(BUFFER+blen, "%02x", cyclep->targetsObject[i].riskStatus);
            blen+=2;
            sprintf(BUFFER+blen, "%04x", cyclep->targetsObject[i].relativeLateralPosition);
            blen+=4;
            sprintf(BUFFER+blen, "%04x", cyclep->targetsObject[i].relativeLongitudinalPosition);
            blen+=4;
            sprintf(BUFFER+blen, "%04x", cyclep->targetsObject[i].relativeLateralVelocity);
            blen+=4;
            sprintf(BUFFER+blen, "%04x", cyclep->targetsObject[i].relativeLongitudinalVel);
            blen+=4;
            sprintf(BUFFER+blen, "%04x", cyclep->targetsObject[i].length);
            blen+=4;
            sprintf(BUFFER+blen, "%04x", cyclep->targetsObject[i].height);
            blen+=4;
            sprintf(BUFFER+blen, "%04x", cyclep->targetsObject[i].width);
            blen+=4;
        }
        //位置信息采集
        if(cyclep->positionFrequency != 0)
        {
            sprintf(BUFFER+blen, "%02x", 0x02);
            blen+=2;
            sprintf(BUFFER+blen, "%02x", cyclep->positionFrequency);
            blen+=2;
            sprintf(BUFFER+blen, "%04x", num*9);
            blen+=4;
        }
        printf("BUFFER:%s\n",BUFFER);
        /*get_current_location();
        printf("longitude:%f %f\n",longitude,latitude);
        long int longitude1=round(longitude*10000)-90;
        long int latitude1=round(latitude*10000)-90;
        printf("latitude1:%ld %ld\n",longitude1,latitude1);*/
        for(int i=0;i<cyclep->positionFrequency;i++)
        {
            for(int j=0;j<MAX_DATA_NUMBER;j++){
            sprintf(BUFFER+blen, "%08x", cyclep->position[j].longitude);
            blen+=8;
            sprintf(BUFFER+blen, "%08x", cyclep->position[j].latitude);
            blen+=8;
            if(longitude<=180 && latitude<90)
            {
                cyclep->position->validMark==0x01;
            }
            else
            {
                cyclep->position->validMark==0x00;
            }
            sprintf(BUFFER+blen, "%02x", cyclep->position->validMark);//位置有效性
            blen+=2;
            }
        }
        printf("BUFFER %s\n",  BUFFER);
        if(cyclep->decisionFrequency != 0)
        {
            sprintf(BUFFER+blen, "%02x", 0x03);
            blen+=2;
            sprintf(BUFFER+blen,"%02x",cyclep->decisionFrequency);
            blen+=2;
            sprintf(BUFFER+blen, "%04x", len_decisionFrequency*21);
            blen+=4;
        }
        //决策信息采集
        for(int i=0;i<len_decisionFrequency;i++)
        {
            sprintf(BUFFER+blen, "%02x", cyclep->decision[i].gear);
            blen+=2;
            sprintf(BUFFER+blen, "%02x", cyclep->decision[i].acceleratorPedal);
            blen+=2;
            sprintf(BUFFER+blen, "%02x", cyclep->decision[i].brakePedal);
            blen+=2;
            //cyclep->decision[i].steeringAngle+= 1080;
            sprintf(BUFFER+blen, "%04x", cyclep->decision[i].steeringAngle);
            blen+=4;

            sprintf(BUFFER+blen, "%02x", cyclep->decision[i].adReqGear);
            blen+=2;
            sprintf(BUFFER+blen, "%04x", cyclep->decision[i].adSysReqRelativeLateralVelocity);
            blen+=4;
            sprintf(BUFFER+blen, "%04x", cyclep->decision[i].adSysReqRelativeLongitudinalVelocity);
            blen+=4;
            sprintf(BUFFER+blen, "%08x", cyclep->decision[i].adSysReqSteeringAngle);
            blen+=8;
            sprintf(BUFFER+blen, "%04x", cyclep->decision[i].adSysReqSteeringTorque);
            blen+=4;
            sprintf(BUFFER+blen, "%04x", cyclep->decision[i].adSysReqLongitudinalMoment);
            blen+=4;
            sprintf(BUFFER+blen, "%04x", cyclep->decision[i].adSysReqFlashLampStatus);
            blen+=4;
            sprintf(BUFFER+blen, "%02x", cyclep->decision[i].adSysReqWiperStatus);
            blen+=2;
        }
        printf("BUFFER1:%s\n",BUFFER);
        if(cyclep->vehiclePerformanceFrequency != 0)
        {
            sprintf(BUFFER+blen, "%02x", 0x05);
            blen+=2;
            sprintf(BUFFER+blen,"%02x",cyclep->vehiclePerformanceFrequency);
            blen+=2;
            sprintf(BUFFER+blen, "%04x",len_vehiclePerformanceFrequency*16);
            blen+=4;
        }
        //整车状态信息高频
        for(int i=0;i<len_vehiclePerformanceFrequency;i++){
            sprintf(BUFFER+blen, "%04x", cyclep->vehiclePerformance[i].instantaneousVelocity);
            blen+=4;
            sprintf(BUFFER+blen, "%04x", cyclep->vehiclePerformance[i].lateralAcceleration);
            blen+=4;
            sprintf(BUFFER+blen, "%04x", cyclep->vehiclePerformance[i].longitudinalAcceleration);
            blen+=4;
            sprintf(BUFFER+blen, "%08x", cyclep->vehiclePerformance[i].headingAngle);
            blen+=8;
            sprintf(BUFFER+blen, "%04x", cyclep->vehiclePerformance[i].yawRate);
            blen+=4;
            sprintf(BUFFER+blen, "%04x", cyclep->vehiclePerformance[i].rollSpeed);
            blen+=4;
            sprintf(BUFFER+blen, "%04x", cyclep->vehiclePerformance[i].pitchAngularVelocity);
            blen+=4;
        }

        printf("BUFFER2:%s\n",BUFFER);
        if(cyclep->sendingDataExternallyFrequency != 0)
        {
            sprintf(BUFFER+blen, "%02x", 0x06);
            blen+=2;
            sprintf(BUFFER+blen,"%02x",cyclep->sendingDataExternallyFrequency);
            blen+=2;
            sprintf(BUFFER+blen, "%04x",len_sendingDataExternallyFrequency*21);
            blen+=4;            
        }
        //交通信息采集
        for(int i=0;i<len_sendingDataExternallyFrequency;i++)
        {
            int ret = string_to_hex(cyclep->sendingDataExternally[i].v2xId,BUFFER+blen);
            //strlen(cyclep->sendingDataExternally[i].v2xId);
            blen+=40;
            printf("len111111111111111:%d", ret);
            sprintf(BUFFER+blen, "%02x", cyclep->sendingDataExternally[i].v2xType);
            blen+=2;
        }
            printf("\n");
            printf("BUFFER3:%s\n",BUFFER);
        if(cyclep->roadInfoFrequency != 0)
        {
            sprintf(BUFFER+blen, "%02x", 0x07);
            blen+=2;
            sprintf(BUFFER+blen,"%02x",cyclep->roadInfoFrequency);
            blen+=2;
            sprintf(BUFFER+blen, "%04x",len_roadInfoFrequency*10);
            blen+=4; 
        }

        //道路信息采集
        for(int i=0;i<len_roadInfoFrequency;i++)
        {
            sprintf(BUFFER+blen, "%04x", cyclep->roadInfo[i].trafficSigns);
            blen+=4;
            sprintf(BUFFER+blen, "%02x", cyclep->roadInfo[i].laneNumber);
            blen+=2;
            sprintf(BUFFER+blen, "%02x", cyclep->roadInfo[i].laneType);
            blen+=2;
            sprintf(BUFFER+blen, "%02x", cyclep->roadInfo[i].roadSpeedLimit);
            blen+=2;
            sprintf(BUFFER+blen, "%04x", cyclep->roadInfo[i].abnormalRoadConditions);
            blen+=4;
            sprintf(BUFFER+blen, "%04x", cyclep->roadInfo[i].trafficControlInfo);
            blen+=4;
            sprintf(BUFFER+blen, "%02x", cyclep->roadInfo[i].frontSignalSign);
            blen+=2;
        }
        printf("\n");
        printf("BUFFER4:%s\n",BUFFER);
        if(cyclep->environmentFrequency != 0)
        {
            sprintf(BUFFER+blen, "%02x", 0x08);
            blen+=2;
            sprintf(BUFFER+blen,"%02x",cyclep->environmentFrequency);
            blen+=2;    
            sprintf(BUFFER+blen, "%04x",len_environmentFrequency*4);
            blen+=4;         
        }

        //自然环境数据采集
        for(int i=0;i<len_environmentFrequency;i++)
        {
            sprintf(BUFFER+blen, "%02x", cyclep->environment[i].externalLightInfo);
            blen+=2;
            sprintf(BUFFER+blen, "%02x", cyclep->environment[i].weatherInfo);
            blen+=2;
            sprintf(BUFFER+blen, "%04x", cyclep->environment[i].externalTemperatureInfo);
            blen+=4;
        }
        printf("\n");
        printf("BUFFER5:%s\n",BUFFER);
        if(cyclep->vehicleStatusFrequency != 0)
        {
            sprintf(BUFFER+blen, "%02x", 0x04);
            blen+=2;
            sprintf(BUFFER+blen,"%02x",cyclep->vehicleStatusFrequency);
            blen+=2;
            sprintf(BUFFER+blen, "%04x",len_vehicleStatusFrequency*40);
            blen+=4; 
        }
        //整车数据低频采集
        for(int i=0;i<len_vehicleStatusFrequency;i++){
            sprintf(BUFFER+blen, "%02x", cyclep->vehicleStatus[i].powerOnStatus);
            blen+=2;
            sprintf(BUFFER+blen, "%02x", cyclep->vehicleStatus[i].controlModel);
            blen+=2;
            sprintf(BUFFER+blen, "%02x", cyclep->vehicleStatus[i].dynamicModel);
            blen+=2;
            sprintf(BUFFER+blen, "%02x", cyclep->vehicleStatus[i].chargeStatus);
            blen+=2;
            sprintf(BUFFER+blen, "%02x", cyclep->vehicleStatus[i].brakingStatus);
            blen+=2;
            sprintf(BUFFER+blen, "%02x", cyclep->vehicleStatus[i].lightSwitch);
            blen+=2;
            sprintf(BUFFER+blen, "%02x", cyclep->vehicleStatus[i].batterySoh);
            blen+=2;
            sprintf(BUFFER+blen, "%02x", cyclep->vehicleStatus[i].currentOilVolume);
            blen+=2;
            sprintf(BUFFER+blen, "%02x", cyclep->vehicleStatus[i].currentCapacity);
            blen+=2;
            sprintf(BUFFER+blen, "%08x", cyclep->vehicleStatus[i].accumulatedMileage);
            blen+=8;
            sprintf(BUFFER+blen, "%02x", cyclep->vehicleStatus[i].wiperStatus);
            blen+=2;
            sprintf(BUFFER+blen, "%04x", cyclep->vehicleStatus[i].networkShape);
            blen+=4;
            sprintf(BUFFER+blen, "%02x", cyclep->vehicleStatus[i].signalStrengthLevel);
            blen+=2;
            sprintf(BUFFER+blen, "%04x", cyclep->vehicleStatus[i].uplinkRate);
            blen+=4;
            sprintf(BUFFER+blen, "%04x", cyclep->vehicleStatus[i].downlinkRate);
            blen+=4;
            sprintf(BUFFER+blen, "%02x", cyclep->vehicleStatus[i].afs);
            blen+=2;
            sprintf(BUFFER+blen, "%02x", cyclep->vehicleStatus[i].esc);
            blen+=2;
            sprintf(BUFFER+blen, "%04x", cyclep->vehicleStatus[i].dcBusVoltage);
            blen+=4;
            sprintf(BUFFER+blen, "%02x", cyclep->vehicleStatus[i].igbtTemperature);
            blen+=2;
            sprintf(BUFFER+blen, "%04x", cyclep->vehicleStatus[i].threePhaseCurrent);
            blen+=4;
            sprintf(BUFFER+blen, "%02x", cyclep->vehicleStatus[i].coolantFlow);
            blen+=2;
            sprintf(BUFFER+blen, "%02x", cyclep->vehicleStatus[i].coolantTemperature);
            blen+=2;
            for(int j=0;j<3;j++)
            {
            sprintf(BUFFER+blen, "%02x", cyclep->vehicleStatus[i].allChargeAndDischargeValue[j]);
            blen+=2;
            }
            sprintf(BUFFER+blen, "%02x", cyclep->vehicleStatus[i].thermalRunawayState);
            blen+=2;
            sprintf(BUFFER+blen, "%02x", cyclep->vehicleStatus[i].equalizingCellStatus);
            blen+=2;
            sprintf(BUFFER+blen, "%04x", cyclep->vehicleStatus[i].currentSignal);
            blen+=4;
            sprintf(BUFFER+blen, "%04x", cyclep->vehicleStatus[i].cellVoltageSignal);
            blen+=4;
            sprintf(BUFFER+blen, "%02x", cyclep->vehicleStatus[i].batteryTemperature);
            blen+=2;
        }
        printf("\n");
        printf("BUFFER6:%s\n",BUFFER);
        if(cyclep->personnelFrequency != 0)
        {
            sprintf(BUFFER+blen, "%02x", 0x0a);
            blen+=2;
            sprintf(BUFFER+blen,"%02x",cyclep->personnelFrequency);
            blen+=2;
            sprintf(BUFFER+blen, "%04x",len_personnelFrequency*4);
            blen+=4;
        }

        //用户数据采集
        for(int i=0;i<len_personnelFrequency;i++)
        {
            sprintf(BUFFER+blen, "%02x", cyclep->personnel[i].seatBeltStatus);
            blen+=2;
            sprintf(BUFFER+blen, "%02x", cyclep->personnel[i].steeringWheelStatus);
            blen+=2;
            sprintf(BUFFER+blen, "%02x", cyclep->personnel[i].driverSeatStatus);
            blen+=2;
            sprintf(BUFFER+blen, "%02x", cyclep->personnel[i].driverTakeOverAbility);
            blen+=2;       
        }
        printf("\n");
        printf("BUFFER7:%s\n",BUFFER);
        if(cyclep->vehicleComponentFrequency != 0)
        {
            sprintf(BUFFER+blen, "%02x", 0x09);
            blen+=2;
            sprintf(BUFFER+blen,"%02x",cyclep->vehicleComponentFrequency);
            blen+=2;
            sprintf(BUFFER+blen, "%04x",len_vehicleComponentFrequency*11);
            blen+=4;
        }

        //系统部件数据采集
        for(int i=0;i<len_vehicleComponentFrequency;i++)
        {
            sprintf(BUFFER+blen, "%02x", cyclep->vehicleComponent[i].airbagStatus);
            blen+=2;
            sprintf(BUFFER+blen, "%02x", cyclep->vehicleComponent[i].gnssStatus);
            blen+=2;
            sprintf(BUFFER+blen, "%02x", cyclep->vehicleComponent[i].imuStatus);
            blen+=2;
            sprintf(BUFFER+blen, "%02x", cyclep->vehicleComponent[i].drivingAutomationSystemStatus);
            blen+=2;
            sprintf(BUFFER+blen, "%02x", cyclep->vehicleComponent[i].highPrecisionMapStatus);
            blen+=2;
            sprintf(BUFFER+blen, "%02x", cyclep->vehicleComponent[i].obuStatus);
            blen+=2;
            sprintf(BUFFER+blen, "%02x", cyclep->vehicleComponent[i].cameraStatus);
            blen+=2;
            sprintf(BUFFER+blen, "%02x", cyclep->vehicleComponent[i].lidarStatus);
            blen+=2;
            sprintf(BUFFER+blen, "%02x", cyclep->vehicleComponent[i].ultrasonicRadarStatus);
            blen+=2;
            sprintf(BUFFER+blen, "%02x", cyclep->vehicleComponent[i].millimeterWaveRadarStatus);
            blen+=2;
            sprintf(BUFFER+blen, "%02x", cyclep->vehicleComponent[i].nightVisionSystemStatus);
            blen+=2;
        }
        printf("blen:%d\n",blen);
        printf("BUFFER8%s\n",BUFFER);
        size_t length = strlen(BUFFER);
        uint8_t Array[length/2];
        printf("%ld\n",length);
        printf("接下来转换数组");
        print_hex((const uint8_t*)BUFFER, length,Array); 
        for(int i = 0; i < length/2; i++)
        {
            printf("%02x ",Array[i]);
        }
        printf("\n");
        // 发送数据到服务端
        ssize_t sent_cycle = send(handle, Array , length/2, 0);
        if (sent_cycle == -1)
        {
            perror("Failed to send data");
            close(handle);
            return ICV_EC_ERROR;
        }
        uint8_t recv_data[4096];
        ssize_t byte_recv = recv(handle,recv_data,sizeof(recv_data),0);
        uint8_t *recvbuf = (uint8_t *)malloc(byte_recv);
        if(byte_recv > 0)
        {
            memcpy(recvbuf, recv_data, byte_recv);
            printf("recv cyclep_data successful\n");
            for(int i=0;i<byte_recv;i++)
            {
                printf("%02x ",recvbuf[i]);
            }
            if(recvbuf[3] ==01 && recvbuf[2]==03)
            {
                printf("收到应答正确\n");
            }
            else
            {
            printf("收到应答数据错误\n");
            }
        }
        else if(byte_recv < 0)
        {
            perror("recv failed");
            icv_sdk_close(handle);
            return ICV_EC_ERROR;
        }
        free(recvbuf);
        return ICV_EC_OK;
    }
    
    //事件数据接口实现
    ICV_CODE_R icv_sdk_eventdata(int handle, ICV_DATA_HEADE *dataHeade, ICV_EVENT_P *eventp)
    {
        if(dataHeade==0||eventp==0)
        {
            return ICV_EC_ERROR;
        }
        char BUF[4096]="232304fe";
        memset(BUF+8,0,sizeof(BUF)-8);
        int blen=strlen(BUF);
        size_t ret = string_to_hex(dataHeade->vin,BUF+blen);
        blen+=34;
        ret = string_to_hex(dataHeade->timeStamp,BUF+blen);
        blen+=26;
        ret = string_to_hex(dataHeade->msgId,BUF+blen);
        blen+=18;
        sprintf(BUF+blen, "%02x", dataHeade->encryptType);
        blen+=2;    
        sprintf(BUF+blen, "%02x", dataHeade->maxDataNum);
        blen+=2;
        string_to_hex(dataHeade->SIM,BUF+blen);
        blen+=40;

        int data_size=0;
        for(int i=0;i<7;i++)
        {
            if(eventp->eventData[i].id >= 1 && eventp->eventData[i].id <= 7)
            {
                if(eventp->eventData[i].id==1)
                {
                   data_size+=14;
                }
                if(eventp->eventData[i].id==2)
                {
                   data_size+=(eventp->eventData[i].vehicleFailure.faultNum*2+11);
                }
                if(eventp->eventData[i].id==3)
                {
                    data_size+=113;
                }
                if(eventp->eventData[i].id==4)
                {
                    data_size+=11;
                }
                if(eventp->eventData[i].id==5)
                {
                   data_size+=1032;
                }
                if(eventp->eventData[i].id==6)
                {
                    data_size+=12;
                }
                if(eventp->eventData[i].id==7)
                {
                    data_size+=(eventp->eventData[i].infoSafe.infoSafetyNum+11);
                }
            }
        }
        printf("data_size%d\n",data_size);
        sprintf(BUF+blen, "%04x",data_size);
        blen+=4;

        /*get_current_location();
        long int longitude1=round(longitude*10000);
        long int latitude1=round(latitude*10000);
        sprintf(BUF+blen,  "%08lx", longitude1);
        blen+=8;
        sprintf(BUF+blen,"%08lx", latitude1);
        blen+=8;
        if(longitude<=180 && latitude<90){
            eventp->eventData->position.validMark=0x01;
        }else{
            eventp->eventData->position.validMark=0x00;
        }
        sprintf(BUF+blen, "%02x", eventp->eventData[0].position.validMark);
        blen+=2;*/

        for(int i=0;i<7;i++)
        {
            if(eventp->eventData[i].id >= 1 && eventp->eventData[i].id <= 7)
            {
                if(eventp->eventData[i].id==1)
                {
                    sprintf(BUF+blen,"%02x",eventp->eventData[i].id);
                    blen+=2;
                    get_current_location();
                    long int longitude1=round(longitude*10000);
                    long int latitude1=round(latitude*10000);
                    sprintf(BUF+blen,  "%08lx", longitude1);
                    blen+=8;
                    sprintf(BUF+blen,"%08lx", latitude1);
                    blen+=8;
                    if(longitude<=180 && latitude<90)
                    {
                        eventp->eventData->position.validMark=0x01;
                    }
                    else
                    {
                        eventp->eventData->position.validMark=0x00;
                    }
                    sprintf(BUF+blen, "%02x", eventp->eventData[0].position.validMark);
                    blen+=2;
                    sprintf(BUF+blen, "%02x",eventp->eventData[i].vehicleCollision.collisionDirection );
                    blen+=2;
                    sprintf(BUF+blen, "%02x",eventp->eventData[i].vehicleCollision.collisionType );
                    blen+=2;
                    sprintf(BUF+blen, "%04x",eventp->eventData[i].vehicleCollision.airbagStatus );
                    blen+=4;
                }
                if(eventp->eventData[i].id==2)
                {
                    sprintf(BUF+blen,"%02x",eventp->eventData[i].id);
                    blen+=2;
                    get_current_location();
                    long int longitude1=round(longitude*10000);
                    long int latitude1=round(latitude*10000);
                    sprintf(BUF+blen,  "%08lx", longitude1);
                    blen+=8;
                    sprintf(BUF+blen,"%08lx", latitude1);
                    blen+=8;
                    if(longitude<=180 && latitude<90)
                    {
                        eventp->eventData->position.validMark=0x01;
                    }
                    else
                    {
                        eventp->eventData->position.validMark=0x00;
                    }
                    sprintf(BUF+blen, "%02x", eventp->eventData[0].position.validMark);
                    blen+=2;
                    sprintf(BUF+blen, "%02x",eventp->eventData[i].vehicleFailure.faultNum );
                    blen+=2;
                    for(int j=0;j<eventp->eventData[i].vehicleFailure.faultNum;j++)
                    {
                        sprintf(BUF+blen, "%02x",eventp->eventData[i].vehicleFailure.failureDetail[j].failureId );
                        blen+=2;
                        sprintf(BUF+blen, "%02x",eventp->eventData[i].vehicleFailure.failureDetail[j].failureType );
                        blen+=2;
                    }
                }
                if(eventp->eventData[i].id==3)
                {
                    sprintf(BUF+blen,"%02x",eventp->eventData[i].id);
                    blen+=2;
                    get_current_location();
                    long int longitude1=round(longitude*10000);
                    long int latitude1=round(latitude*10000);
                    sprintf(BUF+blen,  "%08lx", longitude1);
                    blen+=8;
                    sprintf(BUF+blen,"%08lx", latitude1);
                    blen+=8;
                    if(longitude<=180 && latitude<90)
                    {
                        eventp->eventData->position.validMark=0x01;
                    }
                    else
                    {
                        eventp->eventData->position.validMark=0x00;
                    }
                    sprintf(BUF+blen, "%02x", eventp->eventData[0].position.validMark);
                    blen+=2;
                    sprintf(BUF+blen, "%02x",eventp->eventData[i].vehicleOta.otaStatus);
                    blen+=2;
                    int ret = string_to_hex(eventp->eventData[i].vehicleOta.currentVersion,BUF+blen);
                    blen+=ret;
                    ret = string_to_hex(eventp->eventData[i].vehicleOta.targetVersion,BUF+blen);
                    blen+=ret;
                    sprintf(BUF+blen, "%02x",eventp->eventData[i].vehicleOta.taskDescription );
                    blen+=2;
                    ret = string_to_hex(eventp->eventData[i].vehicleOta.controller,BUF+blen);
                    blen+=ret;
                    ret = string_to_hex(eventp->eventData[i].vehicleOta.influenceFunction,BUF+blen);
                    blen+=ret;
                    ret = string_to_hex(eventp->eventData[i].vehicleOta.changeParameters,BUF+blen);
                    blen+=ret;
                    ret = string_to_hex(eventp->eventData[i].vehicleOta.promptInfo,BUF+blen);
                    blen+=ret;
                    sprintf(BUF+blen, "%02x",eventp->eventData[i].vehicleOta.installConditions );
                    blen+=2;
                }
                if(eventp->eventData[i].id==4)
                {
                    sprintf(BUF+blen,"%02x",eventp->eventData[i].id);
                    blen+=2;
                    get_current_location();
                    long int longitude1=round(longitude*10000);
                    long int latitude1=round(latitude*10000);
                    sprintf(BUF+blen,  "%08lx", longitude1);
                    blen+=8;
                    sprintf(BUF+blen,"%08lx", latitude1);
                    blen+=8;
                    if(longitude<=180 && latitude<90)
                    {
                        eventp->eventData->position.validMark=0x01;
                    }
                    else
                    {
                        eventp->eventData->position.validMark=0x00;
                    }
                    sprintf(BUF+blen, "%02x", eventp->eventData[0].position.validMark);
                    blen+=2;
                    sprintf(BUF+blen, "%02x",eventp->eventData[i].adSystemStateTransition.adSystemEvent );
                    blen+=2;
                }
                if(eventp->eventData[i].id==5)
                {
                    sprintf(BUF+blen,"%02x",eventp->eventData[i].id);
                    blen+=2;
                    get_current_location();
                    long int longitude1=round(longitude*10000);
                    long int latitude1=round(latitude*10000);
                    sprintf(BUF+blen,  "%08lx", longitude1);
                    blen+=8;
                    sprintf(BUF+blen,"%08lx", latitude1);
                    blen+=8;
                    if(longitude<=180 && latitude<90)
                    {
                        eventp->eventData->position.validMark=0x01;
                    }
                    else
                    {
                        eventp->eventData->position.validMark=0x00;
                    }
                    sprintf(BUF+blen, "%02x", eventp->eventData[0].position.validMark);
                    blen+=2;
                    sprintf(BUF+blen, "%02x",eventp->eventData[i].remoteControl.remoteControlStatus );
                    blen+=2;
                    sprintf(BUF+blen, "%02x",eventp->eventData[i].remoteControl.remoteControlType );
                    blen+=2;
                    int ret = string_to_hex(eventp->eventData[i].remoteControl.remoteControlSource,BUF+blen);
                    blen+=40;
                    ret = string_to_hex(eventp->eventData[i].remoteControl.remoteControlDetails,BUF+blen);
                    blen+=2000;  
                }
                if(eventp->eventData[i].id==6)
                {
                    sprintf(BUF+blen,"%02x",eventp->eventData[i].id);
                    blen+=2;
                    get_current_location();
                    long int longitude1=round(longitude*10000);
                    long int latitude1=round(latitude*10000);
                    sprintf(BUF+blen,  "%08lx", longitude1);
                    blen+=8;
                    sprintf(BUF+blen,"%08lx", latitude1);
                    blen+=8;
                    if(longitude<=180 && latitude<90)
                    {
                        eventp->eventData->position.validMark=0x01;
                    }
                    else
                    {
                        eventp->eventData->position.validMark=0x00;
                    }
                    sprintf(BUF+blen, "%02x", eventp->eventData[0].position.validMark);
                    blen+=2;
                    sprintf(BUF+blen, "%02x",eventp->eventData[i].adasEvent.adasSystemId );
                    blen+=2;
                    sprintf(BUF+blen, "%02x",eventp->eventData[i].adasEvent.adasSystemStatus );
                    blen+=2;
                }
                if(eventp->eventData[i].id==7)
                {
                    sprintf(BUF+blen,"%02x",eventp->eventData[i].id);
                    blen+=2;
                    get_current_location();
                    long int longitude1=round(longitude*10000);
                    long int latitude1=round(latitude*10000);
                    sprintf(BUF+blen,  "%08lx", longitude1);
                    blen+=8;
                    sprintf(BUF+blen,"%08lx", latitude1);
                    blen+=8;
                    if(longitude<=180 && latitude<90)
                    {
                        eventp->eventData->position.validMark=0x01;
                    }
                    else
                    {
                        eventp->eventData->position.validMark=0x00;
                    }
                    sprintf(BUF+blen, "%02x", eventp->eventData[0].position.validMark);
                    blen+=2;
                    sprintf(BUF+blen, "%02x",eventp->eventData[i].infoSafe.infoSafetyNum );
                    blen+=2;
                    for(int j=0;j<eventp->eventData[i].infoSafe.infoSafetyNum;j++)
                    {
                        sprintf(BUF+blen, "%02x",eventp->eventData[i].infoSafe.infoSafeDetail[j].infoSafetyId);
                        blen+=2; 
                    }
                }
            }
        }    
        printf("%s\n",BUF);
        size_t length = strlen(BUF);
        uint8_t Array[length/2];
        printf("%ld\n",length);
        printf("接下来转换数组");
        print_hex((const uint8_t*)BUF, length,Array); 
        for(int i = 0; i < length/2; i++)
        {
            printf("%02x ",Array[i]);
        }
        printf("\n");
        // 发送数据到服务端
        ssize_t sent_event = send(handle,Array,length/2, 0);
        if (sent_event == -1)
        {
            perror("Failed to send data");
            close(handle);
            return ICV_EC_ERROR;
        }
        uint8_t recv_data[4096];
        ssize_t byte_recv = recv(handle,recv_data,sizeof(recv_data),0);
        uint8_t *recvbuf = (uint8_t *)malloc(byte_recv);
        if(byte_recv > 0)
        {
            memcpy(recvbuf, recv_data, byte_recv);
            printf("recv event_data successful\n");
            for(int i=0;i<byte_recv;i++)
            {
                printf("%02x ",recvbuf[i]);
            }
            if(recvbuf[2] == 04&&recvbuf[3]==01)
            {
                printf("收到应答正确\n");
            }
            else
            {
            printf("收到应答数据错误\n");
            }
        }
        else if(byte_recv < 0)
        {
            perror("recv failed");
            icv_sdk_close(handle);
            return ICV_EC_ERROR;
        }
        free(recvbuf);
        return ICV_EC_OK;
    }

    ICV_CODE_R icv_sdk_close(int handle)
    {
        if(handle>0)
        {
            close(handle);
            return  ICV_EC_OK;
        }
        return  ICV_EC_OK;
    }


int main() 
{
    //结构体初始化
    ICV_INIT_P initp_data;
    ICV_INIT_C initc_data; 
    ICV_DATA_HEADE dataHeade;
    ICV_LOGIN_P loginp;
    ICV_CYCLE_P cycle_data;
    ICV_EVENT_P event_data;
    ICV_LOGOUT_P logout;
    memset(&initc_data,0,sizeof(ICV_INIT_C));
    memset(&dataHeade,0,sizeof(ICV_DATA_HEADE));
    memset(&loginp,0,sizeof(ICV_LOGIN_P));
    memset(&cycle_data,0,sizeof(ICV_CYCLE_P));
    memset(&event_data,0,sizeof(ICV_EVENT_P));
    memset(&logout,0,sizeof(ICV_LOGOUT_P));
    int ret = -1,handle;
    int i=0;
    char a;
    while(1)
    {
        sleep(3);
        switch(i)
        {
            case 0:
                printf("请输入初始化相关信息\n");
                memset(&initp_data, 0, sizeof(ICV_INIT_P));
                printf("请输入你的ip地址:");
                scanf("%s",initp_data.ip);
                printf("请输入端口号:");
                scanf("%hu",&initp_data.port);
                printf("请输入指定的通信句柄:");
                scanf("%d",&handle);
                ret = icv_sdk_init(&handle, &initp_data, &initc_data);
                if(ret == 1)
                {
                    printf("icv_sdk_init is successed \r\n");
                    i=1;
                }
                else if(ret == -2)
                {
                    printf("icv_sdk_init is failed \r\n");
                    icv_sdk_close(handle);
                    i=0;
                }
                else
                {
                    i=0;
                }
                printf("i:%d",i);
            break;
            case 1:
                printf("请输入数据头相关信息\n"); 
                //数据头信息
                memset(&dataHeade, 0, sizeof(ICV_DATA_HEADE));
                printf("请输入17位vin:");
                scanf("%s",dataHeade.vin);
                printf("请输入13位时间戳:");
                scanf("%s",dataHeade.timeStamp);
                printf("请输入9位消息ID:");
                scanf("%s",dataHeade.msgId);
                printf("请选择加密方式 01 不加密:");
                scanf("%hhu",&dataHeade.encryptType);
                printf("请输入包含数据数量的最大值:");
                scanf("%hhu",&dataHeade.maxDataNum);
                printf("请输入20位SIM卡号:");
                scanf("%s",dataHeade.SIM); 

                printf("请输入车辆登入数据\n");
                //车辆登入数据
                memset(&loginp,0,sizeof(ICV_LOGIN_P));
                printf("请输入流水号:");
                scanf("%hu",&loginp.loginSerialNumber);
                printf("请输入ICCID卡号:");
                scanf("%s",loginp.ICCID);

                int number;
                printf("请输入周期性循环次数:");
                scanf("%d",&number);
                printf("请输入周期性数据\n");
                //周期性数据
                memset(&cycle_data,0,sizeof(ICV_CYCLE_P));
                printf("请输入目标物采集频率:");
                scanf("%hhu",&cycle_data.targetsObjectFrequency);
                for(int i=0;i<cycle_data.targetsObjectFrequency;i++)
                {
                    printf("这是第%d次目标物数据输入:",i+1);
                    printf("请输入感知目标物类型:");
                    scanf("%hhu",&cycle_data.targetsObject[i].type);
                    printf("请输入目标物风险状态:");
                    scanf("%hhu", &cycle_data.targetsObject[i].riskStatus);
                    printf("请输入相对横向位置:");
                    scanf("%hu",&cycle_data.targetsObject[i].relativeLateralPosition);
                    printf("请输入相对纵向位置:");
                    scanf("%hu",&cycle_data.targetsObject[i].relativeLongitudinalPosition);
                    printf("请输入相对横向速度:");
                    scanf("%hu",&cycle_data.targetsObject[i].relativeLateralVelocity);
                    printf("请输入相对纵向速度:");
                    scanf("%hu",&cycle_data.targetsObject[i].relativeLongitudinalVel);
                    printf("请输入目标物长度:");
                    scanf("%hu",&cycle_data.targetsObject[i].length);
                    printf("请输入目标物高度:");
                    scanf("%hu",&cycle_data.targetsObject[i].height);
                    printf("请输入目标物宽度:");
                    scanf("%hu",&cycle_data.targetsObject[i].width);
                }
                printf("\n");
                //printf("请输入位置信息体数据点密度采集频率:");
                //scanf("%hhu",&cycle_data.positionFrequency);

                printf("请输入决策信息体数据点采集频率:");
                scanf("%hhu",&cycle_data.decisionFrequency);
                for(int i=0;i<cycle_data.decisionFrequency;i++)
                {
                    printf("这是第%d次决策数据输入:",i+1);
                    printf("请输入档位信息:");
                    scanf("%hhu",&cycle_data.decision[i].gear);
                    printf("请输入速踏板开度:");
                    scanf("%hhu",&cycle_data.decision[i].acceleratorPedal);
                    printf("请输入刹车踏板开度:");
                    scanf("%hhu",&cycle_data.decision[i].brakePedal);
                    printf("请输入转向盘角度:");
                    scanf("%hu",&cycle_data.decision[i].steeringAngle);
                    printf("请输入AD系统请求挡位:");
                    scanf("%hhu",&cycle_data.decision[i].adReqGear);
                    printf("请输入AD 系统请求的横向加速度:");
                    scanf("%hu",&cycle_data.decision[i].adSysReqRelativeLateralVelocity);
                    printf("请输入AD 系统请求的纵向加速度:");
                    scanf("%hu",&cycle_data.decision[i].adSysReqRelativeLongitudinalVelocity);
                    printf("请输入AD 系统请求的转向角:");
                    scanf("%u",&cycle_data.decision[i].adSysReqSteeringAngle);
                    printf("请输入AD 系统请求的转向力矩:");
                    scanf("%hu",&cycle_data.decision[i].adSysReqSteeringTorque);
                    printf("请输入AD 系统请求的纵向力矩:");
                    scanf("%hu",&cycle_data.decision[i].adSysReqLongitudinalMoment);
                    printf("请输入AD 系统请求的车辆灯光状态:");
                    scanf("%hu",&cycle_data.decision[i].adSysReqFlashLampStatus);
                    printf("请输入AD 系统请求的车辆雨刮状态:");
                    scanf("%hhu",&cycle_data.decision[i].adSysReqWiperStatus);
                }
                printf("\n");
                printf("请输入整车状态信息体数据高频采集频率:");
                scanf("%hhu",&cycle_data.vehiclePerformanceFrequency);
                for(int i=0;i<cycle_data.vehiclePerformanceFrequency;i++)
                {
                    printf("这是第%d次整车数据输入:",i+1);
                    printf("请输入实时车速:");
                    scanf("%hu",&cycle_data.vehiclePerformance[i].instantaneousVelocity);
                    printf("请输入横向加速度:");
                    scanf("%hu",&cycle_data.vehiclePerformance[i].lateralAcceleration);
                    printf("请输入纵向加速度:");
                    scanf("%hu",&cycle_data.vehiclePerformance[i].longitudinalAcceleration);
                    printf("请输入航向角:");
                    scanf("%u",&cycle_data.vehiclePerformance[i].headingAngle);
                    printf("请输入横摆角速度:");
                    scanf("%hu",&cycle_data.vehiclePerformance[i].yawRate);
                    printf("请输入侧倾角速度:");
                    scanf("%hu",&cycle_data.vehiclePerformance[i].rollSpeed);
                    printf("请输入俯仰角速度:");
                    scanf("%hu",&cycle_data.vehiclePerformance[i].pitchAngularVelocity);
                }
                printf("\n");
                printf("请输入交通信息体采集频率:");
                scanf("%hhu",&cycle_data.sendingDataExternallyFrequency);
                for(int i=0;i<cycle_data.sendingDataExternallyFrequency;i++)
                {
                    printf("请输入发送端 ID:");
                    scanf("%s",cycle_data.sendingDataExternally[i].v2xId);
                    printf("请输入数据类型:");
                    scanf("%hhu",&cycle_data.sendingDataExternally[i].v2xType);
                }
                printf("\n");

                printf("请输入道路信息体采集频率:");
                scanf("%hhu",&cycle_data.roadInfoFrequency);
                for(int i=0;i<cycle_data.roadInfoFrequency;i++)
                {
                    printf("请输入交通主标志:");
                    scanf("%hu",&cycle_data.roadInfo[i].trafficSigns);
                    printf("请输入车道序号:");
                    scanf("%hhu",&cycle_data.roadInfo[i].laneNumber);
                    printf("请输入车道类型:");
                    scanf("%hhu",&cycle_data.roadInfo[i].laneType);
                    printf("请输入道路限速信息:");
                    scanf("%hhu",&cycle_data.roadInfo[i].roadSpeedLimit);
                    printf("请输入异常路况信息:");
                    scanf("%hu",&cycle_data.roadInfo[i].abnormalRoadConditions);
                    printf("请输入交通管制信息:");
                    scanf("%hu",&cycle_data.roadInfo[i].trafficControlInfo);
                    printf("请输入所在车道信号灯标识信息:");
                    scanf("%hhu",&cycle_data.roadInfo[i].frontSignalSign);
                }
                printf("\n");
                printf("请输入自然环境信息体数点密度采集频率:");
                scanf("%hhu",&cycle_data.environmentFrequency);
                for(int i=0;i<cycle_data.environmentFrequency;i++)
                {
                    printf("请输入外部光线信息:");
                    scanf("%hhu",&cycle_data.environment[i].externalLightInfo);
                    printf("请输入天气信息:");
                    scanf("%hhu",&cycle_data.environment[i].weatherInfo);
                    printf("请输入外部温度信息:");
                    scanf("%hu",&cycle_data.environment[i].externalTemperatureInfo);
                }

                printf("请输入整车信息体数据低频采集频率:");
                scanf("%hhu",&cycle_data.vehicleStatusFrequency);
                for(int i=0;i<cycle_data.vehicleStatusFrequency;i++)
                {
                    printf("请输入上电状态信息:");
                    scanf("%hhu",&cycle_data.vehicleStatus[i].powerOnStatus);
                    printf("请输入控制模式信息:");
                    scanf("%hhu",&cycle_data.vehicleStatus[i].controlModel);
                    printf("请输入动力模式状态信息:");
                    scanf("%hhu",&cycle_data.vehicleStatus[i].dynamicModel);
                    printf("请输入充电状态信息:");
                    scanf("%hhu",&cycle_data.vehicleStatus[i].chargeStatus);
                    printf("请输入行车制动状态信息:");
                    scanf("%hhu",&cycle_data.vehicleStatus[i].brakingStatus);
                    printf("请输入车灯开关状态:");
                    scanf("%hhu",&cycle_data.vehicleStatus[i].lightSwitch);
                    printf("请输入电池状态信息:");
                    scanf("%hhu",&cycle_data.vehicleStatus[i].batterySoh);
                    printf("请输入当前油量信息:");
                    scanf("%hhu",&cycle_data.vehicleStatus[i].currentOilVolume);
                    printf("请输入当前电量信息:");
                    scanf("%hhu",&cycle_data.vehicleStatus[i].currentCapacity);
                    printf("请输入累计里程信息:");
                    scanf("%u",&cycle_data.vehicleStatus[i].accumulatedMileage);
                    printf("请输入雨刮运行状态信息:");
                    scanf("%hhu",&cycle_data.vehicleStatus[i].wiperStatus);
                    printf("请输入网络形态信息:");
                    scanf("%hu",&cycle_data.vehicleStatus[i].networkShape);
                    printf("请输入信号强度等级信息:");
                    scanf("%hhu",&cycle_data.vehicleStatus[i].signalStrengthLevel);
                    printf("请输入上行速率信息:");
                    scanf("%hu",&cycle_data.vehicleStatus[i].uplinkRate);
                    printf("请输入下行速率信息:");
                    scanf("%hu",&cycle_data.vehicleStatus[i].downlinkRate);
                    printf("请输入AFS自适应前照灯信息:");
                    scanf("%hhu",&cycle_data.vehicleStatus[i].afs);
                    printf("请输入ESC电子稳定性控制系统信息:");
                    scanf("%hhu",&cycle_data.vehicleStatus[i].esc);
                    printf("请输入电机控制器直流母线电压信息:");
                    scanf("%hu",&cycle_data.vehicleStatus[i].dcBusVoltage);
                    printf("请输入电机控制器IGBT 温度信息:");
                    scanf("%hhu",&cycle_data.vehicleStatus[i].igbtTemperature);
                    printf("请输入电机控制器三相电流信息:");
                    scanf("%hu",&cycle_data.vehicleStatus[i].threePhaseCurrent); 
                    printf("请输入冷却液流量信息:");
                    scanf("%hhu",&cycle_data.vehicleStatus[i].coolantFlow);
                    printf("请输入冷却液温度信息:");
                    scanf("%hhu",&cycle_data.vehicleStatus[i].coolantTemperature);
                    printf("请输入累计充放电容量值信息:");
                    for(int j=0;j<3;j++)
                    {
                        scanf("%hhu",&cycle_data.vehicleStatus[i].allChargeAndDischargeValue[j]);
                    }
                    printf("请输入热失控状态信息:");
                    scanf("%hhu",&cycle_data.vehicleStatus[i].thermalRunawayState);
                    printf("请输入均衡电芯状信息:");
                    scanf("%hhu",&cycle_data.vehicleStatus[i].equalizingCellStatus);
                    printf("请输入电流信息:");
                    scanf("%hu",&cycle_data.vehicleStatus[i].currentSignal);
                    printf("请输入电芯电压信息:");
                    scanf("%hu",&cycle_data.vehicleStatus[i].cellVoltageSignal); 
                    printf("请输入电池温度值信息:");
                    scanf("%hhu",&cycle_data.vehicleStatus[i].batteryTemperature);                             
                }
                printf("\n");
                printf("请输入用户信息体数点密度采集频率:");
                scanf("%hhu",&cycle_data.personnelFrequency);
                for(int i=0;i<cycle_data.personnelFrequency;i++)
                {
                    printf("请输入驾乘人员安全带状态:");
                    scanf("%hhu",&cycle_data.personnel[i].seatBeltStatus);
                    printf("请输入驾驶员是否手握方向盘:");
                    scanf("%hhu",&cycle_data.personnel[i].steeringWheelStatus);
                    printf("请输入驾驶员是否在驾驶位:");
                    scanf("%hhu",&cycle_data.personnel[i].driverSeatStatus);
                    printf("请输入驾驶员接管能力监测:");
                    scanf("%hhu",&cycle_data.personnel[i].driverTakeOverAbility);
                }
                printf("\n");
                printf("请输入系统及部件运行状态信息体数点密度采集频率:");
                scanf("%hhu",&cycle_data.vehicleComponentFrequency);
                for(int i=0;i<cycle_data.vehicleComponentFrequency;i++){
                    printf("请输入安全气囊状态:");
                    scanf("%hhu",&cycle_data.vehicleComponent[i].airbagStatus);
                    printf("请输入GNSS 运行状态:");
                    scanf("%hhu",&cycle_data.vehicleComponent[i].gnssStatus);
                    printf("请输入IMU 运行状态:");
                    scanf("%hhu",&cycle_data.vehicleComponent[i].imuStatus);
                    printf("请输入驾驶自动化系统运行状态:");
                    scanf("%hhu",&cycle_data.vehicleComponent[i].drivingAutomationSystemStatus);
                    printf("请输入高精地图运行状态:");
                    scanf("%hhu",&cycle_data.vehicleComponent[i].highPrecisionMapStatus);
                    printf("请输入OBU 运行状态:");
                    scanf("%hhu",&cycle_data.vehicleComponent[i].obuStatus);
                    printf("请输入摄像头运行状态:");
                    scanf("%hhu",&cycle_data.vehicleComponent[i].cameraStatus);
                    printf("请输入激光雷达运行状态:");
                    scanf("%hhu",&cycle_data.vehicleComponent[i].lidarStatus);
                    printf("请输入超声波雷达运行状态:");
                    scanf("%hhu",&cycle_data.vehicleComponent[i].ultrasonicRadarStatus);
                    printf("请输入毫米波雷达运行状态:");
                    scanf("%hhu",&cycle_data.vehicleComponent[i].millimeterWaveRadarStatus);
                    printf("请输入夜视系统运行状态:");
                    scanf("%hhu",&cycle_data.vehicleComponent[i].nightVisionSystemStatus);
                }
                printf("\n");

                printf("请输入事件相关数据\n");
                //事件数据
                memset(&event_data,0,sizeof(ICV_EVENT_P));
                printf("请输入0~7个事件数量:");
                int event;
                scanf("%d",&event);
                for(int i=0;i<event;i++)
                {
                printf("请输入事件ID:");
                scanf("%hhu",&event_data.eventData[i].id);
                    if(event_data.eventData[i].id > 0 && event_data.eventData[i].id < 7){
                        if(event_data.eventData[i].id==1)
                        {
                            printf("请输入碰撞方向:");
                            scanf("%hhu",&event_data.eventData[i].vehicleCollision.collisionDirection);
                            printf("请输入碰撞类型:");
                            scanf("%hhu",&event_data.eventData[i].vehicleCollision.collisionType);
                            printf("请输入气囊状态:");
                            scanf("%hhu",&event_data.eventData[i].vehicleCollision.airbagStatus);
                        }
                        if(event_data.eventData[i].id==2)
                        {
                            printf("请输入故障数量:");
                            scanf("%hhu",&event_data.eventData[i].vehicleFailure.faultNum);
                            for(int j=0;j<event_data.eventData[i].vehicleFailure.faultNum;j++){
                                    printf("请输入故障id:");
                                    scanf("%hhu",&event_data.eventData[i].vehicleFailure.failureDetail[j].failureId);
                                    printf("请输入故障类型:");
                                    scanf("%hhu",&event_data.eventData[i].vehicleFailure.failureDetail[j].failureType);
                                }
                        }
                        if(event_data.eventData[i].id==3)
                        {
                            printf("请输入OTA 状态");
                            scanf("%hhu",&event_data.eventData[i].vehicleOta.otaStatus);
                            printf("请输入当前版本");
                            scanf("%s",event_data.eventData[i].vehicleOta.currentVersion);
                            printf("请输入目标版本:");
                            scanf("%s",event_data.eventData[i].vehicleOta.targetVersion);
                            printf("请输入任务说明:");
                            scanf("%hhu",&event_data.eventData[i].vehicleOta.taskDescription);
                            printf("请输入控制器:");
                            scanf("%s",event_data.eventData[i].vehicleOta.controller);
                            printf("请输入影响功能");
                            scanf("%s",event_data.eventData[i].vehicleOta.influenceFunction);
                            printf("请输入改变参数");
                            scanf("%s",event_data.eventData[i].vehicleOta.changeParameters);
                            printf("请输入提示信息:");
                            scanf("%s",event_data.eventData[i].vehicleOta.promptInfo);
                            printf("请输入安装条件:");
                            scanf("%hhu",&event_data.eventData[i].vehicleOta.installConditions);
                        }
                        if(event_data.eventData[i].id==4)
                        {
                            printf("请输入AD系统事件:");
                            scanf("%hhu",&event_data.eventData[i].adSystemStateTransition.adSystemEvent);
                        }
                        if(event_data.eventData[i].id==5)
                        {
                            printf("请输入远程控制状态");
                            scanf("%hhu",&event_data.eventData[i].remoteControl.remoteControlStatus);
                            printf("请输入远程控制类型");
                            scanf("%hhu",&event_data.eventData[i].remoteControl.remoteControlType);
                            printf("请输入远程控制源:");
                            scanf("%s",event_data.eventData[i].remoteControl.remoteControlSource);
                            printf("请输入远程控制详情:");
                            scanf("%s",event_data.eventData[i].remoteControl.remoteControlDetails);   
                        }
                    }
                    if(event_data.eventData[i].id==6)
                    {
                        printf("请输入ADAS系统ID:");
                        scanf("%hhu",&event_data.eventData[i].adasEvent.adasSystemId);
                        printf("请输入ADAS系统状态:");
                        scanf("%hhu",&event_data.eventData[i].adasEvent.adasSystemStatus);
                    }

                    if(event_data.eventData[i].id==7)
                    {
                        printf("请输入信息安全事件数量");
                        scanf("%hhu",&event_data.eventData[i].infoSafe.infoSafetyNum);
                        for(int j=0;j<event_data.eventData[i].infoSafe.infoSafetyNum;j++){
                            printf("请输入信息安全事件id:");
                            scanf("%hhu",&event_data.eventData[i].infoSafe.infoSafeDetail[j].infoSafetyId);
                        }
                    }
                }
                printf("请输入车辆登出相关信息\n");
                //车辆登出数据
                printf("请输入登出流水号:");
                scanf("%hu",&logout.loginoutNumber);
                printf("%s\n",dataHeade.vin);
                i=2;
            break;
            case 2:  
                //车辆登入函数接口调用
                ret = icv_sdk_carlogin(handle,&dataHeade,&loginp);
                if(ret != ICV_EC_OK)
                {
                    printf("icv_sdk_carlogin error\n");
                    icv_sdk_close(handle);
                    i=0;
                }
                else
                {
                    printf("icv_sdk_carlogin successful\n");
                    i=3;
                }
                break;
            case 3:
                printf("number:%d\n",number);


                for(int j=0;j<number;j++)
                {
                    long int longitude1,latitude1;
                    if(number<1){
                    get_current_location();
                    printf("longitude:%f %f\n",longitude,latitude);
                    longitude1=round(longitude*10000)-90;
                    latitude1=round(latitude*10000)-90;                    
                    }
                    printf("latitude1:%ld %ld\n",longitude1,latitude1);
                    for(int i=0;i<cycle_data.positionFrequency;i++){
                        for(int j=0;i<MAX_DATA_NUMBER;i++){
                        cycle_data.position[j].longitude=longitude1;
                        cycle_data.position[j].latitude=latitude1;
                        }
                    }
                    //周期性数据接口调用
                    ret = icv_sdk_cycledata(handle, &dataHeade, &cycle_data);
                    longitude1+=10;
                    latitude1+=10;

                    if(ret != ICV_EC_OK)
                    {
                        printf("icv_sdk_cycledata error\n");
                        icv_sdk_close(handle);
                        i=0;
                    }
                    else
                    {
                        printf("icv_sdk_cycledata successful\n");
                        i=4;
                    }
                }
                printf("i:%d\n",i);
            break; 
            case 4:    
                ret = icv_sdk_eventdata(handle,&dataHeade, &event_data);
                if(ret != ICV_EC_OK)
                {
                    printf("icv_sdk_eventdata error\n");
                    icv_sdk_close(handle);
                    i=0;
                }
                else
                {
                    printf("icv_sdk_eventdata successful\n");
                    i=5;
                }
            break;
            case 5:
                //车俩登出函数接口调用
                ret = icv_sdk_carlogout(handle,&dataHeade, &logout);
                if(ret != ICV_EC_OK)
                {
                    printf("icv_sdk_carlogout error\n");
                    icv_sdk_close(handle);
                    i=0;
                }
                else
                {
                    printf("icv_sdk_carlogout successful\n");
                    i=6;
                }
            break;
            case 6:
                printf("需要修改数据吗?Y or N?");
                scanf(" %c",&a);
                if(a == 'Y')
                {
                    i=1;
                }
                else
                {
                    i=2;
                }
            break;
        }
    }
}

